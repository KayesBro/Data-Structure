#include<iostream>
#include<string>

using namespace std;
int main()
{
    int s=5;
    string name[s];
    for(int i=0;i<s;i++)
    {
        cout<<"Enter your Your name : ";
        cin>>name[i];
    }
 cout<<"your Your name  is : ";
     for(int i=0;i<s;i++)
    {
        cout<<name[i];

    }

}
