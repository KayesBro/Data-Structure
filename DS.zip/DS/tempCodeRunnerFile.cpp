nt j=1;i<=n;j++)
      {
        cout<<i<<" ";
      }

      cout<<endl;

   }
   

    return 0;
}