#include<iostream>
#include<cstring>
using namespace std;

struct student
{
    char name[20];
    int id;
    double cgpa;
    int comCredit;

};

int main()
{
    //student student[3],s;
    

    char nam[20];
    cout<<"enter name : ";
    cin>>nam;
    cout<<nam<<endl;


   for(int i=0;i<3;i++)
    {
        cout<<"Enter Information For Student "<<i+1<<":"<<endl;
        cout<<"Enter Name : ";
        cin>>student[i].name;
        cout<<"Enter id : ";
        cin>>student[i].id;
        cout<<"Enter Cgpa : ";
        cin>>student[i].cgpa;
        cout<<"Enter comCredit : ";
        cin>>student[i].comCredit;

    }

    for(int i=0;i<3;i++)
    {
        cout<<"Information For Student "<<i+1<<":"<<endl;
        cout<<"Name : "<<student[i].name<<endl;
        cout<<"id : "<<student[i].id<<endl;
        cout<<"cgpa : "<<student[i].cgpa<<endl;
        cout<<"comCredit : "<<student[i].comCredit<<endl;
        
        
    }
    

    return 0;
}