#include<iostream>
using namespace std;

int main()
{
    int c[9];
   int a[5]={1,2,3,4,5};
   int b[4]={6,7,8,9};

    for(int i=0; i<5;i++)
    {
        c[i]=a[i];
    }
    for(int i=0; i<4;i++)
        {
            c[5+i]=b[i];
        }

    for(int i=0; i<9;i++)
    {
        cout<<c[i]<<" ";
    }
    
    return 0;
}