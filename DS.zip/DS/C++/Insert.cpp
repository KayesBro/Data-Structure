#include<iostream>
using namespace std;

int main()
{
    int size=5,val=30,pos=3;
    int arr[size]={1,2,3,4,5};
    for(int i=size;i>=pos-1;i--)
    {
        arr[i+1]=arr[i];
    }
    arr[2]=val;
   size++;
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }

                        
    

    return 0;
}