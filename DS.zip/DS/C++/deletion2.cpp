#include<iostream>
using namespace std;

int main()
{
    int arr[10]={1,2,3,5,3,3,6,7,8,9};
    int dlt=3,index=sizeof(arr)/sizeof(arr[0]);

    for(int i=0;i<index;i++)
    {
        if(arr[i]==dlt)
        {
            for(int j=i;j<index-1;j++)
            {
                arr[j]=arr[j+1];
            }
            index--;
            i--;
        }
        
    }
    for(int i=0;i<index;i++)
    {
        cout<<arr[i]<<" ";
    }
    

    return 0;
}