#include<iostream>
using namespace std;

int main()
{
    int arr[5]={1,2,3,4,5},p,i;
    int first=arr[0];
    for( p=0;p<2;p++)
    {
       for( i=0;i<5;i++)
       {
          arr[i-1]=arr[i];
       }
        arr[4]=first; 
    }
    
    cout<<"Shifting Array is : "<<endl;
    for( i=0;i<5;i++)
        cout<<arr[i]<<" ";
    return 0;
}