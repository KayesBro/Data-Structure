#include<iostream>
using namespace std;

int main()
{
    int arr[10]={1,2,3,4,5,6,7,8,9,10};
    int dltVal=5,i,flag=0;

    for( i=0;i<10;i++)
    {
        if(arr[i]==dltVal)
        {
            flag=1;
            break;
        }
    }

    if(flag==0)
    {
        cout<<"Delete Element Not Found"<<endl;
    }
    else
    {
        for(i ;i<9;i++)
        {
            arr[i]=arr[i+1];
        }

        cout<<"Final Elements "<<endl;
        for( i=0;i<9;i++)
         {
             cout<<arr[i]<<" ";
         }
    }
    



    return 0;
}