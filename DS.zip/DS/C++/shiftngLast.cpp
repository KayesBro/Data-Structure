#include<iostream>
using namespace std;

int main()
{
    int a[5]={1,2,3,4,5};

    for(int i=0; i<2; i++)
    {
        int last=a[4];

         for(int i=3;i>=0;i--)
         {
             a[i+1]=a[i];
         }
        a[0]=last;
    }
    

    for(int i=0;i<5;i++)
    {
        cout<<a[i]<<" ";
    }

    return 0;
}