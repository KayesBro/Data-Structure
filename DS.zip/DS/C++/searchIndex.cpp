#include<iostream>
using namespace std;

int main()
{
    int search=30,pos;

    int arr[5]={10,20,30,40,50};
    for(int i=0;i<5; i++)
    {
        if(arr[i]==search)
        {
            pos=i;
        }
    }

    cout<<"search index is :"<<pos<<endl;


    return 0;
}