#include<iostream>
using namespace std;

int main()
{
    int arr[5]={12,2,313,43,53};
    int m=arr[0];

    for(int i=1;i<5; i++)
    {
        if(m>arr[i])
        {
           m=arr[i];
        }
    
    }

    cout<<"small number is : "<<m<<endl;
 
    return 0;
}