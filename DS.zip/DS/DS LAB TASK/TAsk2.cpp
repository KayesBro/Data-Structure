#include<iostream>
using namespace std;

int main()
{
    int arr[]={1,2,3,4,5,6,7,8,9,10};
    int size=sizeof(arr)/sizeof(int),i;

    cout<<"Delete an element from the end of the array"<<endl;
    for( i=0;i<size-1;i++)
    {

        cout<<arr[i]<<" ";
    }
    cout<<endl;

    cout<<"Delete an element from the beginning of the array"<<endl;
    for( i=0;i<size;i++)
    {

       arr[i]=arr[i+1];
    }
    for( i=0;i<size-1;i++)
    {

        cout<<arr[i]<<" ";
    }
    cout<<endl;

    cout<<"Delete an element from the  specific index  of the array"<<endl;

    for( i=0;i<size-1;i++)
    {
        if(i==3)
        {
            continue;;;
           
        }
         cout<<arr[i]<<" ";
    }





    return 0;
}