#include<iostream>
using namespace std;

int main()
{
    int arr[4][2]={{1,2},{3,4},{5,6},{7,8}};
    int arrT[2][4],i,j;
cout<<"Orginal mattrix"<<endl;
    for(i=0;i<4;i++)
    {
        for(j=0;j<2;j++)
        {
            cout<<arr[i][j]<<" ";
        }

    }
    

   for(i=0;i<4;i++)
    {
        for(j=0;j<2;j++)
        {
            arrT[j][i]=arr[i][j];
        }
    }
    cout<<"Transpose mattrix"<<endl;
 for(i=0;i<2;i++)
    {
        for(j=0;j<4;j++)
        {
            cout<<arrT[i][j]<<" ";
        }
        cout<<endl;
    }
    



    return 0;
}