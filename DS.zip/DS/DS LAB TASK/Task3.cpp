#include <iostream>
using namespace std;

int main() {
    int arr[] = {92, 82, 21, 16, 18, 95, 25, 10};
    int size = 8;
    int temp,comp=0;
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    int low=0;high=size-1,search=92;

    int mid=low+(high-low)/2;
    while(low<=high)
    {
        if(arr[mid]==search)
        {
            cout<<"found in index"<<mid<<endl;
            comp++

        }
        else if (arr[mid] < search) 
        {
            low = mid + 1;
        } 
        else
         {
            high = mid - 1;
        }

    }


    return 0;
}