#include<iostream>
using namespace std;
int main()
{
    int num[5];
    int sum=0;
    for(int i=0;i<5;i++)
    {
        cout<<"Enter array number index "<<i<<" : ";
        cin>>num[i];
    }
    cout<<endl;

     for(int i=0;i<5;i++)
    {
       sum=sum+num[i];
    }
      cout<<sum<<endl;

}
