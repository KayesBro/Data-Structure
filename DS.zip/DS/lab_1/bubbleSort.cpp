#include<iostream>
using namespace std;

int main()
{
    int arr[]={23,65,124,35,6,23,45,66,134,56,2,3512};
    int size=sizeof(arr)/sizeof(int);
    int temp,comp;
cout<<"--------UnSorted Array-------"<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }

    for(int i=0;i<size-1;i++)
    {
        for(int j=0;j<size-1-i;j++)
        {
            if(arr[j]>arr[j+1])
            {
                temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }

    }
    cout<<endl;
    cout<<"--------Sorted Array-------"<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }
   


    return 0;
}