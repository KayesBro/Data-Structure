temp=arr[i];
            arr[i]=arr[min];
            arr[min]=temp;
