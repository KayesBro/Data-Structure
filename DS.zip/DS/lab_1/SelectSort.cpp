#include<iostream>
using namespace std;

int main()
{
    int arr[]={23,65,124,35,6,23,45,66,134,56,2,3512};
    int size=sizeof(arr)/sizeof(int);
    int temp,min;

    for(int i=0;i<size-1;i++)
    {
        min=i;
        
        for(int j=i+1;j<size;j++)
        {
            if(arr[min]>arr[j])
            {
                min=j;
            }
           
        }
        
            temp=arr[i];
            arr[i]=arr[min];
            arr[min]=temp;

        

    }

    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }

    return 0;
}