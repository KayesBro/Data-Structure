#include<iostream>
using namespace std;

int main()
{
    int arr[]={1,1,1,2,2,3,3,3,3,3,4,4,4,5};
    int size=sizeof(arr)/sizeof(int);
    for(int i=0;i<size;i++)
    {
        bool alreadyCounted=false;

        for(int j=0;j<i;j++)
        {
            if(arr[i]==arr[j])
            {
                alreadyCounted=true;
                break;
            }
        }

        if(!alreadyCounted)
        {
            int count = 0;

            for(int k=0;k<size;k++)
            {
                if(arr[i]==arr[k])
                {
                    count++;
                }
            }
    
        cout<<arr[i]<<" occurs = "<<count;
        if(count==1)
        {
            cout<<" time"<<endl;
        }
        else 
        {
            cout<<" times"<<endl;
        }
    }


    }

    return 0;
}