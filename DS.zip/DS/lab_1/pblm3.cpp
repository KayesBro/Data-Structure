#include<iostream>
using namespace std;

void oddNumber(int sv,int ev)
{

    for(int i=sv;i<=ev;i++)
    {
        if(i%2!=0)
        {
            cout<<i<<" ";
        }
    }
}


int main()
{
    int sv,ev;
    cout<<"Enter Starting Value : ";
    cin>>sv;

    cout<<"Enter Ending Value : ";
    cin>>ev;

    oddNumber(sv,ev);


    return 0;
}