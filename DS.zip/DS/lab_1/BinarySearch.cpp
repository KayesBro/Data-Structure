#include<iostream>
using namespace std;

int main()
{
    int arr[]={23,65,124,35,6,23,45,66,134,56,2,3512};
    int size=sizeof(arr)/sizeof(int);
    int temp;

    //Bubble Sort
    for(int i=0;i<size-1;i++)
    {
        for(int j=0;j<size-1-i;j++)
        {
            if(arr[j]>arr[j+1])
            {
                temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    int search,low=0,high=size-1,comp=0;
    bool found=false;
    cout<<"ENter number for search: ";
    cin>>search;

    while(low<=high)
    {
        int mid = low+(high-low)/2;

        if(arr[mid]==search)
        {
            cout<<search<<" found at index of "<<mid<<" in the sorted array"<< endl;
            comp++;
            found=true;
            break;
        }
        else if(arr[mid]<search)
        {
            low=mid+1;
        }
        else
        {
            high=mid-1;
        }

    }

    if(!found)
    {
        cout<<"search element not founded!!!!"<<endl;
    }
    cout << "Number of comparisons = " << comp << endl;


cout<<"---------- Sorted arry ----------\n"<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }

    return 0;
}