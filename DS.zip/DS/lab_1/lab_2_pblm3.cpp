#include<iostream>
using namespace std;

void removeDup(int arr[],int siz)
{
    bool isDuplicate=false;

    for(int i=0;i<siz;i++)
    {
        for(int j=i+1;j<siz;)
        {
            if(arr[i]==arr[j])
            {
                isDuplicate=true;

                for(int k=j;k<siz-1;k++)
                {
                    arr[k]=arr[k+1];
                }
                siz--;

            }
            else
            {
                j++;
            }
        }
    }

    if(isDuplicate)
    {
        for(int i=0;i<siz;i++)
        {
            cout<<arr[i]<<" ";
        }
    }
    else 
    {
        cout<<"Alraedy Unique Elements."<<endl;
    }

}


int main()
{
    int arr[]={1,2,3,4,3,3,5,6};
    int arr2[]={1,2,3,4,5,6,8,7};

    int size1=sizeof(arr)/sizeof(arr[0]);
    int size2=sizeof(arr2)/sizeof(arr[0]);

    removeDup(arr2,size2);
    removeDup(arr,size1);


    /*bool isDuplicate=false;

    for(int i=0;i<size1;i++)
    {
        for(int j=i+1;j<size1;)
        {
            if(arr[i]==arr[j])
            {
                isDuplicate=true;

                for(int k=j;k<size1-1;k++)
                {
                    arr[k]=arr[k+1];
                }
                size1--;

            }
            else
            {
                j++;
            }
        }
    }

    if(isDuplicate)
    {
        for(int i=0;i<size1;i++)
        {
            cout<<arr[i]<<" ";
        }
    }
    else 
    {
        cout<<"Alraedy Unique Elements."<<endl;
    }
    */


    return 0;
}