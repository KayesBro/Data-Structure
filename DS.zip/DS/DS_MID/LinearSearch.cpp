#include<iostream>
using namespace std;

int main()
{
    int arr[]={1,2,3,4,5,6,7,7,8,89,12};
    int size=sizeof(arr)/sizeof(arr[0]),search=89;

    for(int i=0;i<size;i++)
    {
        if(arr[i]==search)
        {
            cout<<arr[i]<<" is found at index of "<<i<<endl;
            break;
        }
    }

    return 0;
}