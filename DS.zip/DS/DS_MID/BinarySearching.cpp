#include<iostream>
using namespace std;

int main()
{
    int arr[]={32,45,3,23,66,8,5,25,67,786};
    int size=sizeof(arr)/sizeof(arr[0]),temp;

    for(int i=0;i<size-1;i++)
    {
        for(int j=0;j<size-1-i;j++)
        {
            if(arr[j]>arr[j+1])
            {
                temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    cout<<"--------Sorted Array-----------"<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    int search;
    cout<<"Enter number for search : ";
    cin>>search;

    int low=0,high=size-1,comp=0;
    bool found=false;

    while(low<=high)
    {
        int mid=low+(high-low)/2;
        comp++;

        if(arr[mid]==search)
        {
            cout << search << " found at index " << mid << " in the sorted array" << endl;
            found=true;
            break;

        }
        else if(arr[mid]<search)
        {
            low=mid+1;
        }
        else 
        {
            high=mid-1;
        }
    }
    if (!found) 
    {
        cout << "Not found" << endl;
    cout << "Number of comparisons = " << comp << endl;
    }




    return 0;
}