#include<iostream>
using namespace std;

int main()
{
    int arr[]={1,2,3,3,3,3,33,5,6,7,4,5};
    int size=sizeof(arr)/sizeof(arr[0]),dlt=3;

    for(int i=0;i<size;i++)
    {
            if(arr[i]==dlt)
            {
                for(int j=i;j<size-1;j++)
                {
                    arr[j]=arr[j+1];
                }
                size--;
                i--;
            }
    }
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }
    


    return 0;
}