#include<iostream>
using namespace std;

int main()
{
    int arr[]={32,45,3,23,66,8,5,25,67,786};
    int size=sizeof(arr)/sizeof(arr[0]);
    int temp;
    cout<<"-------- Orgonal array----------"<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;

    for(int i=0;i<9;i++)
    {
        for(int j=i+1;j<10;j++)
        {
            if(arr[i]>arr[j])
            {
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
        }
    }

    cout<<"--------Bubble sorted array----------"<<endl;

    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }


    return 0;
}