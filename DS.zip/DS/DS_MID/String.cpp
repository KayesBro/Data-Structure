#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    char str[100];
    cout<<"enter any word : ";
    cin.getline(str,100);

    cout<<"output : "<<str;
    

    return 0;
}