#include <iostream>
#include <string>
using namespace std;

// Constants
const int MAX_APPLICANTS_PER_TYPE = 25;
const int MAX_TOTAL_APPLICANTS = 100;
const int TOTAL_COUNTERS = 4;

// Applicant structure
struct Applicant {
    int globalToken;
    string visaType;
};

// Counter structure
struct Counter {
    string primaryVisa;
    int servedTokens[100];
    int servedCount;
};

// Global variables
Applicant applicants[MAX_TOTAL_APPLICANTS];
int totalApplicants = 0;
int totalServedApplicants = 0;

Counter counters[TOTAL_COUNTERS] = {
    {"TR", {}, 0},
    {"MED", {}, 0},
    {"BS", {}, 0},
    {"GO", {}, 0}
};

// Queues for each visa type
int TRQueue[25], MEDQueue[25], BSQueue[25], GOQueue[25];
int frontTR = 0, rearTR = 0;
int frontMED = 0, rearMED = 0;
int frontBS = 0, rearBS = 0;
int frontGO = 0, rearGO = 0;

// Visa counts
int visaCountTR = 0, visaCountMED = 0, visaCountBS = 0, visaCountGO = 0;

// Helper to convert to uppercase manually
string toUpper(string str) {
    for (int i = 0; str[i]; i++) {
        if (str[i] >= 'a' && str[i] <= 'z') {
            str[i] -= 32;
        }
    }
    return str;
}

// Issue a token
void issueToken(string visaTypeInput) {
    if (totalApplicants >= MAX_TOTAL_APPLICANTS) {
        cout << "Daily applicant limit reached!" << endl;
        return;
    }

    visaTypeInput = toUpper(visaTypeInput);

    if (visaTypeInput != "TR" && visaTypeInput != "MED" && visaTypeInput != "BS" && visaTypeInput != "GO") {
        cout << "Invalid visa type!" << endl;
        return;
    }

    if ((visaTypeInput == "TR" && visaCountTR >= MAX_APPLICANTS_PER_TYPE) ||
        (visaTypeInput == "MED" && visaCountMED >= MAX_APPLICANTS_PER_TYPE) ||
        (visaTypeInput == "BS" && visaCountBS >= MAX_APPLICANTS_PER_TYPE) ||
        (visaTypeInput == "GO" && visaCountGO >= MAX_APPLICANTS_PER_TYPE)) {
        cout << "Daily limit reached for this visa type!" << endl;
        return;
    }

    applicants[totalApplicants].globalToken = totalApplicants + 1;
    applicants[totalApplicants].visaType = visaTypeInput;

    cout << "Your token is: " << visaTypeInput << "-" << applicants[totalApplicants].globalToken << endl;

    if (visaTypeInput == "TR") {
        TRQueue[rearTR++] = totalApplicants;
        visaCountTR++;
    } else if (visaTypeInput == "MED") {
        MEDQueue[rearMED++] = totalApplicants;
        visaCountMED++;
    } else if (visaTypeInput == "BS") {
        BSQueue[rearBS++] = totalApplicants;
        visaCountBS++;
    } else if (visaTypeInput == "GO") {
        GOQueue[rearGO++] = totalApplicants;
        visaCountGO++;
    }

    totalApplicants++;
}

// Find the longest queue
int findLongestQueue() {
    int sizes[4] = {rearTR - frontTR, rearMED - frontMED, rearBS - frontBS, rearGO - frontGO};
    int maxSize = -1, index = -1;
    for (int i = 0; i < 4; i++) {
        if (sizes[i] > maxSize) {
            maxSize = sizes[i];
            index = i;
        }
    }
    return (maxSize > 0) ? index : -1;
}

// Call next customer
void callNextCustomer(int counterNumber) {
    counterNumber--; // make 0-indexed
    if (counterNumber < 0 || counterNumber >= TOTAL_COUNTERS) {
        cout << "Invalid counter number!" << endl;
        return;
    }

    if (totalServedApplicants >= totalApplicants) {
        cout << "All applicants have been served for today!" << endl;
        return;
    }

    bool served = false;
    string primary = counters[counterNumber].primaryVisa;

    // Serve primary visa first
    if (primary == "TR" && frontTR < rearTR) {
        int idx = TRQueue[frontTR++];
        counters[counterNumber].servedTokens[counters[counterNumber].servedCount++] = applicants[idx].globalToken;
        cout << "Counter " << counterNumber + 1 << ", Please serve the token number \""
             << applicants[idx].visaType << "-" << applicants[idx].globalToken << "\"" << endl;
        served = true;
    } else if (primary == "MED" && frontMED < rearMED) {
        int idx = MEDQueue[frontMED++];
        counters[counterNumber].servedTokens[counters[counterNumber].servedCount++] = applicants[idx].globalToken;
        cout << "Counter " << counterNumber + 1 << ", Please serve the token number \""
             << applicants[idx].visaType << "-" << applicants[idx].globalToken << "\"" << endl;
        served = true;
    } else if (primary == "BS" && frontBS < rearBS) {
        int idx = BSQueue[frontBS++];
        counters[counterNumber].servedTokens[counters[counterNumber].servedCount++] = applicants[idx].globalToken;
        cout << "Counter " << counterNumber + 1 << ", Please serve the token number \""
             << applicants[idx].visaType << "-" << applicants[idx].globalToken << "\"" << endl;
        served = true;
    } else if (primary == "GO" && frontGO < rearGO) {
        int idx = GOQueue[frontGO++];
        counters[counterNumber].servedTokens[counters[counterNumber].servedCount++] = applicants[idx].globalToken;
        cout << "Counter " << counterNumber + 1 << ", Please serve the token number \""
             << applicants[idx].visaType << "-" << applicants[idx].globalToken << "\"" << endl;
        served = true;
    }

    // Serve from longest queue if primary empty
    if (!served) {
        int longest = findLongestQueue();
        if (longest == -1) {
            cout << "No applicants left to serve." << endl;
            return;
        }

        int idx = -1;
        if (longest == 0) {
            idx = TRQueue[frontTR++];
        } else if (longest == 1) {
            idx = MEDQueue[frontMED++];
        } else if (longest == 2) {
            idx = BSQueue[frontBS++];
        } else if (longest == 3) {
            idx = GOQueue[frontGO++];
        }

        counters[counterNumber].servedTokens[counters[counterNumber].servedCount++] = applicants[idx].globalToken;
        cout << "Counter " << counterNumber + 1 << ", Please serve the token number \""
             << applicants[idx].visaType << "-" << applicants[idx].globalToken << "\"" << endl;
    }

    totalServedApplicants++;
}

// Generate daily summary
void generateSummary() {
    int servedTR = 0, servedMED = 0, servedBS = 0, servedGO = 0;

    for (int i = 0; i < totalApplicants; i++) {
        if (applicants[i].visaType == "TR") servedTR++;
        else if (applicants[i].visaType == "MED") servedMED++;
        else if (applicants[i].visaType == "BS") servedBS++;
        else if (applicants[i].visaType == "GO") servedGO++;
    }

    cout << "\nApplicants served by Visa Type:" << endl;
    cout << "TR (Travel): " << servedTR << endl;
    cout << "MED (Medical): " << servedMED << endl;
    cout << "BS (Business): " << servedBS << endl;
    cout << "GO (Government Officials): " << servedGO << endl;

    cout << "\nApplicants served by Counter:" << endl;
    for (int i = 0; i < TOTAL_COUNTERS; i++) {
        cout << "Counter " << (i + 1) << " (" << counters[i].primaryVisa << "): ";
        if (counters[i].servedCount == 0) {
            cout << "Idle";
        } else {
            for (int j = 0; j < counters[i].servedCount; j++) {
                int idx = counters[i].servedTokens[j] - 1;
                cout << applicants[idx].visaType << "-" << applicants[idx].globalToken;
                if (j != counters[i].servedCount - 1) cout << ", ";
            }
        }
        cout << endl;
    }

    int idleCount = 0;
    for (int i = 0; i < TOTAL_COUNTERS; i++) {
        if (counters[i].servedCount == 0) idleCount++;
    }

    cout << "\nIdle Counters: " << idleCount << endl;
    cout << "Total Applicants Served: " << totalServedApplicants << "/" << totalApplicants << endl;
}

// Main function
int main() {
    int choice;
    while (true) {
        cout << "\n--- Embassy Consulate Service System ---" << endl;
        cout << "1. Request Token" << endl;
        cout << "2. Call Next Customer at Counter" << endl;
        cout << "3. Generate Daily Summary" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            cout << "Enter Visa Type (TR/MED/BS/GO): ";
            string type;
            cin >> type;
            issueToken(type);
        } else if (choice == 2) {
            cout << "Enter Counter Number (1-4): ";
            int counterNo;
            cin >> counterNo;
            callNextCustomer(counterNo);
        } else if (choice == 3) {
            generateSummary();
        } else if (choice == 4) {
            cout << "Exiting the system." << endl;
            break;
        } else {
            cout << "Invalid choice!" << endl;
        }
    }

    return 0;
}
