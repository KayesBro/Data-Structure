#include<iostream>
using namespace std;

int main()
{
    int a[3][3]={{12,13,14},{15,16,17},{18,19,20}};
    int b[3][3]={{1,2,3},{4,5,6},{7,8,9}};
    int c[3][3]={{101,104,107},{102, 105, 108 },{103, 106 ,109 }};
    int d[10][10],e[10][10],sum=0;
    for(int i=0;i<3;i++)
    {
        for(int j=0; j<3;j++)
        {
           d[i][j]=a[i][j] + b[i][j];
        }
    }

    for(int i=0;i<3;i++)
    {
        for(int j=0; j<3;j++)
        {
            e[i][j]=d[i][j]+c[i][j];
        }
    }


   cout<<"------------Output---------------"<<endl;
   cout<<"------------A---------------"<<endl;
   for(int i=0;i<3;i++)
   {
       for(int j=0; j<3;j++)
       {
           cout<<a[i][j]<<" ";
       }
       cout<<endl;
   }
   
   cout<<"------------B---------------"<<endl;
   for(int i=0;i<3;i++)
   {
       for(int j=0; j<3;j++)
       {
           cout<<b[i][j]<<" ";
       }
       cout<<endl;
   }
   cout<<"------------C---------------"<<endl;
   for(int i=0;i<3;i++)
   {
       for(int j=0; j<3;j++)
       {
           cout<<c[i][j]<<" ";
       }
       cout<<endl;
   }
   cout<<"------------Addtion Between 3 Matrices---------------"<<endl;
   for(int i=0;i<3;i++)
   {
       for(int j=0; j<3;j++)
       {
           cout<<e[i][j]<<" ";
       }
       cout<<endl;
   }
   

          
    
    return 0;
}
