#include<iostream>
using namespace std;

void oddNumber(int s,int e)
{
    int size=(e-s)+1;
    int arr[size];
    for(int i=0;i<size;i++)
    {
        arr[i]=s+i;
        
    }
    for(int i=0;i<size;i++)
    {
        if(arr[i]%2!=0)
        {
            cout<<arr[i]<<" ";
        }
    }
}




int main()
{
   
    oddNumber(12,23);

    

    return 0;
}