#include <iostream>
using namespace std;

void primeNumber(int n)
{
    int flag=0,fact=1;
    for(int i=1;i<=n;i++)
    {
        if(n%i==0)
        {
            flag++;
        }
    }
    if(flag==2)
    {
        
        for(int i=1; i<=n;i++)
        {
            fact=fact*i;
        }
        cout<<"fact is :"<<fact<<endl;
            
    }
    else
    {
        cout<<"Error! Not a prime number."<<endl;
    }
}

int main() 
{
    int n;
    cout << "Enter a number: ";
    cin >> n;
    primeNumber(n);
    return 0;
}