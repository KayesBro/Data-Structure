#include<iostream>
using namespace std;

int main()
{
    int arr[10],search,count=0;
    cout<<"Enter 10 number : ";
    for(int i=0;i<10;i++)
    {
        cin>>arr[i];
    }
    cout<<"Number to search :";
    cin>>search;
    for(int i=0;i<10;i++)
    {
        if(arr[i]==search)
        {
            count++;

        }
    }
    cout<<"The number occurs"<<count;
    if(count==1)
    {
        cout<<" time in the array "<<endl;
    }
    else
    {
        cout<<" times in the array"<<endl;
    }
    

    return 0;
}