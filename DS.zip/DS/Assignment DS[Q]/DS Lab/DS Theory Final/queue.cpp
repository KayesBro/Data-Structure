#include<iostream>
using namespace std;
class node
{
    public :
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }
};
class queue
{
    public : 
    node* front;
    node* rear;
    public :
    queue()
    {
        front=rear=NULL;
    }
    void enQueue(int val)
    {
        node* newNode=new node(val);
        if(front==NULL)
        {
            front=rear=newNode;
            return;
        }
        rear->next=newNode;
        rear=newNode;
    }
    void deQueue()
    {
        if(front==NULL)
        {
            cout<<"Queue UnderFlow"<<endl;
            return;
        }
        front=front->next;
    }
    void display()
    {
        node* temp=front;
        while(temp!=NULL)
        {
            cout<<temp->data<<"->";
            temp=temp->next;
        }
        cout<<endl;
    }

};
int main()
{
    queue q;
    q.enQueue(3);
    q.enQueue(5);
    q.enQueue(7);
    q.display();
    q.deQueue();
    q.display();
    q.enQueue(10);
    q.display();

    return 0;
}