#include<iostream>
using namespace std;
class node
{
    public :
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }
};
class circularQueue
{
    public :
    node* front;
    node* rear;
    public :
    circularQueue()
    {
        front=rear=NULL;
    }
    void enQueue(int val)
    {
        node* newNode=new node(val);
        if(front==NULL)
        {
            front=rear=newNode;
            rear->next=front;
            return;
        }
        rear->next=newNode;
        rear=newNode;
        rear->next=front;
    }
    void deQueue()
    {
        if(front==NULL)
        {
            cout<<"Queue underFlow"<<endl;
            return;
        }
        if(front==rear)
        {
            delete front;
            front=rear=NULL;
        }
        node* temp=front;
        front=front->next;
        rear->next=front;
        delete temp;
    }
   void display() {
    if (front == nullptr) {
        cout << "Queue is empty.\n";
        return;
    }
    node* temp = front;
    while (true) 
    {
        cout << temp->data << " ";
        temp = temp->next;
        if(temp==front)
        {
            break;
        }
    }  
          cout << endl;
}

};
int main()
{
    circularQueue q;
    q.enQueue(10);
    q.enQueue(20);
    q.enQueue(30);
    q.display();
    q.deQueue();
    q.display();

    

    return 0;
}