#include<iostream>
using namespace std;
class node
{
    public :
    int data;
    node* next;
    node* prev;
    node(int val)
    {
        data=val;
        next=NULL;
        prev=NULL;
    }
};
void insertAtLast(node* head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newNode;
    newNode->prev=temp;
}
void insertAtFirst(node* &head,int val)
{
    node* newNode=new node(val);
    newNode->next=head;
    if(head!=NULL)
    {
        head->prev=newNode;
    }
    head=newNode;
}
void insertAnyPos(node* &head,int pos,int val)
{
    node* newNode=new node(val);
    if(pos<=0)
    {
        cout<<"Invalid pos"<<endl;
        return;
    }
    node* temp=head;
    for(int i=1;i<pos-1;i++)
    {
        temp=temp->next;
    }
    newNode->next=temp->next;
    newNode->prev=temp;
    if(temp->next!=NULL)
    {
        temp->next->prev=newNode;
        temp->next=newNode;
    }
}
void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << "->";
        temp = temp->next;
    }
    cout << "null" << endl;
}

void deleteAtFirst(node* &head)
{
    if(head==NULL)
    {
        cout<<"UnderFlow linklist"<<endl;
        return;
    }
   node* temp=head;
   head=head->next;
   if(head!=NULL)
   {
    head->prev=NULL;
   }
   delete temp;
}
void deleteAtLast(node* head)
{
    if(head==NULL)
    {
        cout<<"UnderFlow linklist"<<endl;
        return;
    }
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->prev->next=NULL;
    delete temp;
}
void deleteAnyPos(node* &head,int pos)
{
    if(pos<=0)
    {
        cout<<"Invalid position"<<endl;
        return;
    }
    node* temp=head;
    for(int i=1;i<pos;i++)
    {
        temp=temp->next;
    }
    temp->prev->next=temp->next;
    temp->next->prev=temp->prev;
    delete temp;
}

int main()
{
     node* head = new node(18);
    node* second = new node(15);
    node* third = new node(17);

    head->next = second;
    second->prev = head;
    second->next = third;
    third->prev = second;

    insertAtLast(head, 10);
    display(head);

    insertAtFirst(head, 16);
    display(head);

    insertAnyPos(head, 3, 12);
    display(head);

    deleteAtFirst(head);
    display(head);

    deleteAtLast(head);
    display(head);
    
    deleteAnyPos(head,2);
    display(head);


    return 0;
}