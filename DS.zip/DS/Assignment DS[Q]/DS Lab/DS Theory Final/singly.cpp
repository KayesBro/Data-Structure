#include<iostream>
using namespace std;
class node
{
    public :
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }
};
void insertAtLast(node* head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newNode;
}
void insertAtFirst(node* &head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    newNode->next=head;
    head=newNode;
}
void insertAnyPosition(node* &head,int pos,int val)
{
    node* newNode=new node(val);
    if(pos<=0)
    {
        cout<<"Invalid position"<<endl;
        return;
    }
    node* temp=head;
    for(int i=1;i<pos-1;i++)
    {
        temp=temp->next;
    }
    newNode->next=temp->next;
    temp->next=newNode;
}
void deleteAtFirst(node* &head)
{
    if(head==NULL)
    {
        cout<<"LinkList UnderFlow"<<endl;
        return;
    }
    head=head->next;
}
void deleteAtLast(node* head)
{
    if(head==NULL)
    {
        cout<<"LinkList UnderFlow"<<endl;
        return;
    }
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=NULL;
}
void deleteAnyPosition(node* head,int pos)
{
    if(pos<=0)
    {
        cout<<"Invalid position"<<endl;
        return;
    }
    node* temp=head;
    for(int i=1;i<pos-1;i++)
    {
        temp=temp->next;
    }
    temp->next=temp->next->next;
}
void display(node* head)
{
    node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<"->";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}
int main()
{
    node* head=new node(18);
node* second=new node(15);
node* third=new node(17);
head->next=second;
second->next=third;
//display(head);
insertAtLast(head, 10);
display(head);
cout<<endl;
insertAtFirst(head,16);
display(head);
cout<<endl;
insertAnyPosition(head, 3, 12);
display(head);
cout<<endl;
deleteAtFirst(head);
display(head);
cout<<endl;
deleteAtLast(head);
display(head);
cout<<endl;
deleteAnyPosition(head,3);
display(head);
cout<<endl;

    return 0;
}