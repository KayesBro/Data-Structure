#include <iostream>
using namespace std;


class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) {
        data = value;
        left = right = nullptr;
    }
};


class BST {
public:
   Node* root;
    Node* insert(Node* node, int value) {
        if (node == nullptr) {
            return new Node(value);
        }
        if (value < node->data)
            node->left = insert(node->left, value);
        else if (value > node->data)
            node->right = insert(node->right, value);
        return node;
    }
    // Helper for in-order traversal
    void inorder(Node* node) {
        if (node == nullptr) return;
        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }

    // Helper for pre-order traversal
    void preorder(Node* node) {
        if (node == nullptr) return;
        cout << node->data << " ";
        preorder(node->left);
        preorder(node->right);
    }

    // Helper for post-order traversal
    void postorder(Node* node) {
        if (node == nullptr) return;
        postorder(node->left);
        postorder(node->right);
        cout << node->data << " ";
    }

    // Helper for searching
    Node* search(Node* node, int key) {
        if (node == nullptr || node->data == key)
            return node;
        if (key < node->data)
            return search(node->left, key);
        else
            return search(node->right, key);
    }

public:
    BST() {
        root = nullptr;
    }

    void insert(int value) {
        root = insert(root, value);
    }

    void inorder() {
        cout << "In-order Traversal: ";
        inorder(root);
        cout << endl;
    }

    void preorder() {
        cout << "Pre-order Traversal: ";
        preorder(root);
        cout << endl;
    }

    void postorder() {
        cout << "Post-order Traversal: ";
        postorder(root);
        cout << endl;
    }

    void search(int key) {
        Node* result = search(root, key);
        if (result != nullptr)
            cout << key << " found in BST.\n";
        else
            cout << key << " not found in BST.\n";
    }
};

// Main function to demonstrate
int main() {
    BST tree;

    // Inserting elements
    tree.insert(50);
    tree.insert(30);
    tree.insert(20);
    tree.insert(40);
    tree.insert(70);
    tree.insert(60);
    tree.insert(80);

    // Traversals
    tree.inorder();
    tree.preorder();
    tree.postorder();

    // Searching elements
    tree.search(40);  // Found
    tree.search(90);  // Not found

}