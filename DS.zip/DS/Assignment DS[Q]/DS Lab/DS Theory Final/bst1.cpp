#include<iostream>
using namespace std;
class Node
{
    public :
    int data;
    Node* left;
    Node* right;
    Node(int val)
    {
        data=val;
        left=right=NULL;
    }
};
class BST
{
    public :
    Node* root;
    Node* insert(Node* node,int val)
    {
        if(node==NULL)
        {
            return new Node(val);
        }
        if(val<node->data)
        {
            node->left=insert(node->left,val);
        }
        else if(val>node->data)
        {
            node->right=insert(node->right,val);
        }
        return node;
    }
     void inorder(Node* node)
     {
        if(node==NULL)
        {
            return;
        }
        inorder(node->left);
        cout<<node->data<<" ";
        inorder(node->right);
     }
     void preorder(Node* node)
     {
        if(node==NULL)
        {
            return;
        }
        cout<<node->data<<" ";
        preorder(node->left);
        preorder(node->right);
     }
     void postorder(Node* node)
     {
        if(node==NULL)
        {
            return;
        }
        postorder(node->left);
        postorder(node->right);
        cout<<node->data<<" ";
     }

    public : 
    BST()
    {
        root=NULL;
    }
    void insert(int val)
    {
        root=insert(root,val);
    }
    void inorder()
    {
        cout<<"Inorder Traversal : ";
        inorder(root);
        cout<<endl;
    }
    void preorder()
    {
        cout<<"Pre-Order Traversal : ";
        preorder(root);
        cout<<endl;
    }
    void postorder()
    {
        cout<<"Post-Order Traversal : ";
        postorder(root);
        cout<<endl;
    }
};
int main()
{
     BST t;
     t.insert(50);
     t.insert(20);
     t.insert(80);
     t.insert(120);
     t.insert(100);

     t.inorder();
     t.preorder();
     t.postorder();
    

    return 0;
}