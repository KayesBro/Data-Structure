#include<iostream>
using namespace std;
class node
{
    public :
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }
};
class stack
{
    public:
    node* top;
    public: 
    stack()
    {
        top=NULL;
    }
    bool isEmpty()
    {
        if(top==NULL)
        {
            return true;
        }
        return false;
    }
    void push(int val)
    {
        node* newNode=new node(val);
        if(isEmpty()==true)
        {
            top=newNode;
            return;
        }
        newNode->next=top;
        top=newNode;
    }
    void pop()
    {
        if(isEmpty()==true)
        {
            cout<<"Stack UnderFlow"<<endl;
            return;
        }
        top=top->next;
    }
    void display()
    {
        node* curr=top;
        while(curr!=NULL)
        {
            cout<<curr->data<<"->";
            curr=curr->next;
        }
        cout<<endl;
    }
};
int main()
{
    stack s;
    s.push(1);
    s.push(5);
    s.push(10);
    s.push(13);
    s.display();
    s.pop();
    s.display();

    return 0;
}