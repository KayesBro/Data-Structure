#include<iostream>
using namespace std;
void removeDuplicate(int arr[],int size)
{
    int unique[size];
    int newSize = 0;

    for(int i=0;i<size; i++)
    {
        bool isDuplicate = false;
        for(int j=0; j<newSize; j++)
        {
            if(arr[i]==unique[j])
            {
                isDuplicate = true;
                break;
            }
        }
        if(!isDuplicate)
    {
        unique[newSize] = arr[i];
        newSize++;
    }
    }
    
    if(newSize == size)
    {
        cout<<"Array already unique!"<<endl;
    }
}

int main()
{
    int arr1[]={1,4,6,3,6,9,1};
    int arr2[]={1,4,5,3,6,9};

    int size1 = sizeof(arr1) / sizeof(arr1[0]);
    int size2 = sizeof(arr2) / sizeof(arr2[0]);

    removeDuplicate(arr1, size1);
    removeDuplicate(arr2, size2);


    

    return 0;
}