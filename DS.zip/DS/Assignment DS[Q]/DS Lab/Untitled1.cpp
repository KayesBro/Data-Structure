#include<iostream>
using namespace std;
class node{
public:
    int data;
    node* next;

    node(int value){
    data=value;
    next=nullptr;
    }

};
class stack{
public:
node* top;
public:
stack(){
top=nullptr;
}
bool isEmpty(){
if(top==nullptr){
    return true;
}

return false;
}
void push(int value){
    node* newNode=new node(value);
    if(isEmpty()==true){
       top=newNode;
        return;
    }

newNode->next=top;
top=newNode;
}
void pop(){
if(isEmpty()){
    cout<<"stack underflow";
    return;
}
top=top->next;
}
void display(){
node* current=top;
while(current!=nullptr){
    cout<<current->data<<"->";
    current=current->next;
}

}
};

int main(){
stack s;

s.push(5);
s.push(6);
s.push(7);
s.display();
s.pop();
cout<<endl;
s.display();
}


