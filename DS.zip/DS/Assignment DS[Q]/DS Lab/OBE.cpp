#include<iostream>
using namespace std;
int main()
{
    int arr[]={105,89,54,32,76,210,63,41};
    int size=sizeof(arr)/sizeof(arr[0]);
    int temp,comp=0;

    for(int i=0;i<size-1;i++)
    {
        for(int j=0;j<size-1-i;j++)
        {
            if(arr[j]>arr[j+1])
            {
                temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }

        }
        comp++;
    }
    int search,low=0,high=size-1;
    bool found=false;
    cout<<"Enter your number for search : ";
    cin>>search;
    while(low<=high)
    {
        int mid=low+(high-low)/2;
        if(arr[mid]==search)
        {
            cout<<search<<" is found at index "<<mid<<endl;
            found=true;
            break;
        }
        else if(arr[mid]<search)
        {
            low=mid+1;
        }
        else
        {
            high=mid-1;
        }
    }

    if(!found)
    {
        cout<<"Not Found"<<endl;
    }
    cout<<"number of comp is : "<<comp<<endl;
cout<<"---------- Sorted Array -------"<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" " ;
    }

    return 0;
}
