#include<iostream>
using namespace std;

class node {
public:
    int Priority;
    node* next;
    node* prev;

    node(int val) {
        Priority = val;
        next = nullptr;
        prev = nullptr;
    }
};

void insertAtLast(node* head,int val)
{
    node* newNode= new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    node* temp= head;
    while(temp->next != NULL)
    {
        temp=temp->next;
    }
    temp->next=newNode;
    newNode->prev=temp;
}
void insertAtHead(node* &head,int val)
{
    node* newNode=new node(val);
    newNode->next=head;
    if(head!=NULL)
    {
        head->prev=newNode;
    }
    head=newNode;
}
void deleteAtHead(node* &head)
{
    if(head==NULL)
    {
        return;
    }
    node* temp= head;
    head=head->next;
    if(head->next!=NULL)
    {
        head->prev=NULL;
    }
    delete temp;
}
void deleteAtLast(node* &head)
{
    if(head==NULL)
    {
        return;
    }
    if(head->next==NULL)
    {
        delete head;
        head=NULL;
        return;
    }
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->prev->next=NULL;
    delete temp;
}
void display(node* head)
{
    node* temp = head;
    while(temp != NULL)
    {
        cout<<temp->Priority<<"->";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}

int main()
{
    node* head=new node(18);
    node* second=new node(15);
    node* third=new node(17);
    head->next=second;
    second->next=third;
        
    insertAtLast(head,9);
    insertAtHead(head,5);
    display(head);
    deleteAtHead(head);
    deleteAtLast(head);
    display(head);

    return 0;
}