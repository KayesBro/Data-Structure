#include<iostream>
using namespace std;
class node
{
    public : 
    int data;
    node* next;

    node(int val)
    {
        data=val;
        next=NULL;
    }
};

void insertAtLast(node* head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newNode;
}

void insertAtFirst(node* &head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    newNode->next=head;
    head=newNode;
}

void deleteAtLast(node* head)
{
    if(head==NULL)
    {
        cout<<"UnderFlow"<<endl;
    }
    node* temp=head;
    while(temp->next->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=NULL;
}

void deleteAtFirst(node* &head)
{
    if(head==NULL)
    {
        cout<<"UnderFlow"<<endl;
    }
    head=head->next;
}

void insertAnyPosition(node* &head,int pos,int val)
{
    
}

int search(node* head,int key)
{
    node* temp=head;
    while(temp!=NULL)
    {
        if(temp->data==key)
        {
            return 1;
        }
        temp=temp->next;
    }
    return 0;
}

void display(node* head)
{
    node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<"->";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}
int main()
{
    node* head=new node(3);
    node* second=new node(5);
    node* third=new node(7);

    head->next=second;
    second->next=third;
    insertAtLast(head,9);
    display(head);
    insertAtFirst(head,1);
    display(head);
    deleteAtLast(head);
    display(head);
    deleteAtFirst(head);
    display(head);
    int found=search(head,9);
    if(found)
    {
        cout<<"Founded!!!!!"<<endl;
    }
    else
    cout<<"NOt Founded!!!!!"<<endl;
    

    return 0;
}