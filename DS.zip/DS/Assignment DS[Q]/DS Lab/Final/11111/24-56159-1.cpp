#include<iostream>
using namespace std;
class node
{
    public: 
    int data;
    node* next;
    node* prev;
    node(int val)
    {
        data=val;
        next=NULL;
        prev=NULL;
    }
};

void addStudentAtLast(node* &head,int val)
{
    node* newNode=new node(val);
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newNode;
    newNode->prev=temp;
}
void deleteStudent(node* &head)
{
    int pos=0;
    node* temp=head;
    while(temp!=NULL)
    {
        if(temp->data==25)
        {
            break;
        }
        temp=temp->next;
        pos++;
    }
    for(int i=1;i<pos&& temp&&NULL;i++)
    {
        temp=temp->next;
    }
    temp->prev->next=temp->next;
    temp->next->prev=temp->prev;

}
void displayForward(node* &head)
{
    node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<"<=>";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}
void displayBackward(node* &head)
{
    node* temp = head;
    while(temp->next!= NULL)
    {
        temp=temp->next;
    }
    while(temp!=NULL)
    { 
        cout<<temp->data<<"<=>";
        temp=temp->prev;
        
    }
    cout<<"NULL"<<endl;
}

class queue
{
    public: 
    node* front;
    node* rear;
    public: 
    queue()
    {
        front=rear=NULL;
    }
    void enQueue(int val)
    {
        node* newNode=new node(val);
        if(front==NULL)
        {
            front = rear = newNode;
            return;
        }
        rear->next=newNode;
        rear=newNode;
    }

    void deQueue()
    {
        if(front==NULL)
        {
            cout<<"Queue UnderFlow"<<endl;
            return;
        }
        front=front->next;
    }
    void display()
    {
        node* temp=front;
        while(temp!=NULL)
        {
            cout<<temp->data<<"->";
            temp=temp->next;
        }
        cout<<"NULL"<<endl;
    }

};

class Node 
{
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) 
    {
        data = value;
        left = right = nullptr;
    }
};
class BST 
{
public:
   Node* root;
    Node* insert(Node* node, int value) 
    {
        if (node == nullptr) 
        {
            return new Node(value);
        }
        if (value < node->data)
            node->left = insert(node->left, value);
        else if (value > node->data)
            node->right = insert(node->right, value);
        return node;
    }
   
    void inorder(Node* node) 
    {
        if (node == nullptr) return;
        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }

    void preorder(Node* node) 
    {
        if (node == nullptr) return;
        cout << node->data << " ";
        preorder(node->left);
        preorder(node->right);
    }

    void postorder(Node* node) 
    {
        if (node == nullptr) return;
        postorder(node->left);
        postorder(node->right);
        cout << node->data << " ";
    }

public:
    BST()
    {
        root = nullptr;
    }

    void insert(int value) {
        root = insert(root, value);
    }

    void inorder() 
    {
        cout << "Inorder Traversal: "<<endl;
        inorder(root);
        cout << endl;
    }

    void preorder()
     {
        cout << "Preorder Traversal: "<<endl;
        preorder(root);
        cout << endl;
     }

    void postorder() 
    {
        cout << "Postorder Traversal: "<<endl;
        postorder(root);
        cout << endl;
    }
};

int main()
{
    node* head = new node(12);
    node* second = new node(25);
    node* third = new node(34);
    node* tail = new node(41);

    head->next = second;
    second->prev = head;
    second->next = third;
    third->prev = second;
    third->next=tail;
    tail->prev=third;
    addStudentAtLast(head,56);
    deleteStudent(head);
    cout<<"Student List (Forward):  "<<endl;
    displayForward(head);
    cout<<"Student List (Backward): "<<endl; 
    displayBackward(head);
    cout<<endl;

    cout<<"Course Registration Queue:  "<<endl;
    queue q;
    q.enQueue(101);
    q.enQueue(102);
    q.enQueue(103);
    q.enQueue(104);
    q.enQueue(105);
    q.deQueue();
    q.display();

    cout<<endl;
    BST t;
    t.insert(60);
    t.insert(30);
    t.insert(10);
    t.insert(40);
    t.insert(20);
    t.insert(80);
    t.insert(100);
    t.insert(70);
    t.insert(90);
    t.inorder();
    t.preorder();
    t.postorder();
    

    return 0;
}