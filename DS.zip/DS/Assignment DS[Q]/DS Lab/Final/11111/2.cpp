#include<iostream>
using namespace std;
class node
{
    public: 
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }
};
class queue
{
    public: 
    node* front;
    node* rear;
    public: 
    queue()
    {
        front=rear=NULL;
    }
    void enQueue(int val)
    {
        node* newNode=new node(val);
        if(front==NULL)
        {
            front = rear = newNode;
            return;
        }
        rear->next=newNode;
        rear=newNode;
    }

    void deQueue()
    {
        if(front==NULL)
        {
            cout<<"Queue UnderFlow"<<endl;
            return;
        }
        front=front->next;
    }
    void display()
    {
        node* temp=front;
        while(temp!=NULL)
        {
            cout<<temp->data<<"->";
            temp=temp->next;
        }
        cout<<"NULL"<<endl;
    }

};

int main()
{
    queue q;
    q.enQueue(101);
    q.enQueue(102);
    q.enQueue(103);
    q.enQueue(104);
    q.enQueue(105);
    q.deQueue();
    q.display();
  
    return 0;
}