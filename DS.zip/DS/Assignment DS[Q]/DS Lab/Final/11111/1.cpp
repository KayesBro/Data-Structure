#include<iostream>
using namespace std;
class node
{
    public: 
    int data;
    node* next;
    node* prev;
    node(int val)
    {
        data=val;
        next=NULL;
        prev=NULL;
    }
};

void addStudentAtLast(node* &head,int val)
{
    node* newNode=new node(val);
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newNode;
    newNode->prev=temp;
}
void deleteStudent(node* &head)
{
    int pos=0;
    node* temp=head;
    while(temp!=NULL)
    {
        if(temp->data==25)
        {
            break;
        }
        temp=temp->next;
        pos++;
    }
    for(int i=1;i<pos&& temp&&NULL;i++)
    {
        temp=temp->next;
    }
    temp->prev->next=temp->next;
    temp->next->prev=temp->prev;

}
void displayForward(node* &head)
{
    node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<"<=>";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}
void displayBackward(node* &head)
{
    node* temp = head;
    while(temp->next!= NULL)
    {
        temp=temp->next;
    }
    while(temp!=NULL)
    { 
        cout<<temp->data<<"<=>";
        temp=temp->prev;
        
    }
    cout<<"NULL"<<endl;
}

int main()
{
    node* head = new node(12);
    node* second = new node(25);
    node* third = new node(34);
    node* tail = new node(41);

    head->next = second;
    second->prev = head;
    second->next = third;
    third->prev = second;
    third->next=tail;
    tail->prev=third;
    addStudentAtLast(head,56);
    deleteStudent(head);
    displayForward(head);
    displayBackward(head);
    

    return 0;
}