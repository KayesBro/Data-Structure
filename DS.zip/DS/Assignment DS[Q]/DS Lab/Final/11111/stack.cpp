#include<iostream>
using namespace std;
class node
{
    public : 
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }

};
class stack
{
    public : 
    node* top;
    stack()
    {
        top=NULL;
    }
    bool isEmpty()
    {
        if(top==NULL)
        {
            return true;
        }
        return false;
    }
    void push(int val)
    {
        node* newNode=new node(val);
        if(isEmpty()==true)
        {
            top=newNode;
            return;
        }
        newNode->next=top;
        top=newNode;
    }
    void pop()
    {
        if(isEmpty()==true)
        {
            cout<<"Stack UnderFlow"<<endl;
            return;
        }
        top=top->next;
    }
    void display()
    {
        node* temp=top;
        while(temp!=NULL)
        {
            cout<<temp->data<<"->";
            temp=temp->next;
        }
        cout<<"NULL"<<endl;
    }
};


int main()
{
    stack s;
    s.push(3);
    s.push(5);
    s.push(7);
    s.display();
    s.pop();
    s.display();
    

    return 0;
}