#include<iostream>
using namespace std;
class node
{
    public : 
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }
};
void insertAtLast(node* head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newNode;
}

void insertAtFirst(node* &head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    newNode->next=head;
    head=newNode;
}

void insertAtPosition(node* &head,int pos,int val)
{
    if(pos<=0)
    {
        cout<<"Invalid Position"<<endl;
    }
    node* newNode=new node(val);
    node* temp=head;
    for(int i=1;i<pos-1;i++)
    {
        temp=temp->next;
    }
    newNode->next=temp->next;
    temp->next=newNode;
}

void deleteAtFirst(node* &head)
{
    if(head==NULL)
    {
        cout<<"Underflow"<<endl;
        return;
    }
    head=head->next;
}
void deleteAtLast(node* head)
{
    node* temp=head;
    while(temp->next->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=NULL;

}

void display(node* head){

node* temp=head;
while(temp!=nullptr){
    cout<<temp->data<<"->";
    temp=temp->next;

}
cout<<"null";

}

int main()
{
    node* head=new node(18);
    node* second=new node(15);
    node* third=new node(17);
    head->next=second;
    second->next=third;
    //display(head);
    insertAtLast(head, 10);
    display(head);
    cout<<endl;
    insertAtFirst(head,16);
    display(head);
    cout<<endl;
    insertAtPosition(head, 3, 12);
    display(head);
    cout<<endl;
    deleteAtFirst(head);
    deleteAtLast(head);
    display(head);
    
    return 0;
}