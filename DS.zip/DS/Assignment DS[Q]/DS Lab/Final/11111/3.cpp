#include <iostream>
using namespace std;
class Node 
{
public:
    int data;
    Node* left;
    Node* right;

    Node(int value) 
    {
        data = value;
        left = right = nullptr;
    }
};
class BST 
{
public:
   Node* root;
    Node* insert(Node* node, int value) 
    {
        if (node == nullptr) 
        {
            return new Node(value);
        }
        if (value < node->data)
            node->left = insert(node->left, value);
        else if (value > node->data)
            node->right = insert(node->right, value);
        return node;
    }
   
    void inorder(Node* node) 
    {
        if (node == nullptr) return;
        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }

    void preorder(Node* node) 
    {
        if (node == nullptr) return;
        cout << node->data << " ";
        preorder(node->left);
        preorder(node->right);
    }

    void postorder(Node* node) 
    {
        if (node == nullptr) return;
        postorder(node->left);
        postorder(node->right);
        cout << node->data << " ";
    }

public:
    BST()
    {
        root = nullptr;
    }

    void insert(int value) {
        root = insert(root, value);
    }

    void inorder() 
    {
        cout << "Inorder Traversal: "<<endl;
        inorder(root);
        cout << endl;
    }

    void preorder()
     {
        cout << "Preorder Traversal: "<<endl;
        preorder(root);
        cout << endl;
     }

    void postorder() 
    {
        cout << "Postorder Traversal: "<<endl;
        postorder(root);
        cout << endl;
    }
};

int main() 
{
    BST t;
    t.insert(60);
    t.insert(30);
    t.insert(10);
    t.insert(40);
    t.insert(20);
    t.insert(80);
    t.insert(100);
    t.insert(70);
    t.insert(90);
    t.inorder();
    t.preorder();
    t.postorder();

}
