#include<iostream>
using namespace std;

class node
{
    public : 
    int taskid;
    node* Priority;

    node(int value)
    {
        taskid=value;
        Priority=nullptr;
    }

};

void insertAtEnd(node* &head,int value)
{
    node* newNode=new node(value);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    node* temp=head;
    while(temp->Priority!=NULL)
    {
        temp= temp->Priority;
    }
    temp->Priority=newNode;
}


void display(node* head)
{
    node* temp=head;
    while(temp!=nullptr)
    {
        cout<<temp->taskid<<"->";
        temp=temp->Priority;
    }
    cout<<"NULL"<<endl;

}


int main()
{
    node* head=new node(18);
    node* second=new node(15);
    node* third=new node(17);
    head->Priority=second;
    second->Priority=third;
        
    insertAtEnd(head,9);
    insertAtEnd(head,11);
    display(head);
    

    return 0;
}