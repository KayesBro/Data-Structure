#include<iostream>
using namespace std;

class node {
public:
    int taskid;
    node* Priority;
    node* prev;

    node(int val) {
        taskid = val;
        Priority = nullptr;
        prev = nullptr;
    }
};

void insertAtLast(node* head,int val)
{
    node* newNode= new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    node* temp= head;
    while(temp->Priority != NULL)
    {
        temp=temp->Priority;
    }
    temp->Priority=newNode;
    newNode->prev=temp;
}
void insertAtHead(node* &head,int val)
{
    node* newNode=new node(val);
    newNode->Priority=head;
    if(head!=NULL)
    {
        head->prev=newNode;
    }
    head=newNode;
}
void deleteAtHead(node* &head)
{
    if(head==NULL)
    {
        return;
    }
    node* temp= head;
    head=head->Priority;
    if(head->Priority!=NULL)
    {
        head->prev=NULL;
    }
    delete temp;
}
void deleteAtLast(node* &head)
{
    if(head==NULL)
    {
        return;
    }
    if(head->Priority==NULL)
    {
        delete head;
        head=NULL;
        return;
    }
    node* temp=head;
    while(temp->Priority!=NULL)
    {
        temp=temp->Priority;
    }
    temp->prev->Priority=NULL;
    delete temp;
}
void displayHtoT(node* head)
{
    node* temp = head;
    while(temp != NULL)
    {
        cout<<temp->taskid<<"->";
        temp=temp->Priority;
    }
    cout<<"NULL"<<endl;
}
void displayTtoH(node* tail)
{
    node* temp = tail;
    while(temp != NULL)
    {
        cout<<temp->taskid<<"->";
        temp=temp->prev;
    }
    cout<<"NULL"<<endl;
}

int main()
{
    node* head=new node(18);
    node* second=new node(15);
    node* tail=new node(17);
    head->Priority=second;
    second->Priority=tail;

    tail->prev=second;
    second->prev=head;
        
    insertAtLast(head,9);
    insertAtHead(head,5);
    displayHtoT(head);
    deleteAtHead(head);
    deleteAtLast(head);
    displayHtoT(head);
    displayTtoH(tail);

    return 0;
}