#include<iostream>
using namespace std;
class node
{
    public : 
    int data;
    node* prev;
    node* next;

    node(int val)
    {
        data=val;
        prev=NULL;
        next=NULL;
    }
};

void insertAtFirst(node* &head,int val)
{
    node* newNode=new node(val);
    newNode->next=head;
    head->prev=newNode;
    head=newNode;
}

void insertAnyPos(node* &head,int pos,int val)
{
    if(pos<=0)
    {
        cout<<"Invalid Position"<<endl;
        return;
    }
    if(pos==1)
    {
        insertAtFirst(head,val);
        return;
    }
    node* newNode=new node(val);
    node* temp=head;
    for(int i=1;i<pos-1 && temp!=NULL;i++)
    {
        temp=temp->next;
    }
    newNode->next=temp->next;
    newNode->prev=temp;
    if(temp->next!=NULL)
    {
        temp->next->prev=newNode;
    }
    temp->next=newNode;

}

void deleteAtLast(node* &head)
{
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->prev->next=NULL;
    delete temp;
}

void deleteAnyPos(node* &head,int pos)
{
    if(pos<=0)
    {
        cout<<"Invalid Position"<<endl;
        return;
    }
    node* temp=head;
    for(int i=1;i<=pos;i++)
    {
        temp=temp->next;
    }
    if(temp==NULL)
    {
        deleteAtLast(head);
        return;
    }
    temp->prev->next=temp->next;
    temp->next->prev=temp->prev;
    delete temp;
}

int foundPosOfVal(node* head,int val)
{ 
    int c=1;
    node* temp=head;
    while(temp->next!=NULL)
    {
        if(temp->data==val)
        {
            
            break;
        }
        temp=temp->next;
            c++;
    }
   return c;
}

int divisibleByTwo(node* &head)
{
    int d=0;
    node* temp=head;
    while(temp!=NULL)
    {
        if(temp->data%2==0)
        {
            d++;
        }
        temp=temp->next;
    }
    return d;
}

int highestVal(node* &head)
{
    int max=head->data;
    node* temp=head;
    while(temp!=NULL)
    {
        if(temp->data>max)
        {
            max=temp->data;

        }
        temp=temp->next;
    }
    return max;
}

void doublyToSingle(node* &head) 
{
    node* temp = head;
    while (temp != NULL) 
    {
        temp->prev = NULL; 
        temp = temp->next;
    }
}

void display(node* &head)
{
    node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<"<=>";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}

class stack
{
    public : 
    node* top;
   public : 
    stack()
    {
        top=NULL;
    }
    
    void push(int val)
    {
        node* newNode=new node(val);
        if(top==NULL)
        {
            top=newNode;
            return;
        }
        newNode->next=top;
        top=newNode;
    }
    void pop()
    {
        if(top==NULL)
        {
            cout<<"Stack UnderFlow"<<endl;
            return;
        }
        top=top->next;
    }

    void displayStack()
    {
        node* temp=top;
        while(temp!=NULL)
        {
            cout<<temp->data<<"->";
            temp=temp->next;
        }
        cout<<"NULL"<<endl;
    }
};

int main()
{
    node* head=new node(12);
    node* sec=new node(35);
    node* thir=new node(8);
    node* four=new node(47);
    node* fif=new node(18);
    head->next=sec;
    sec->prev=head;
    sec->next=thir;
    thir->prev=sec;
    thir->next=four;
    four->prev=thir;
    four->next=fif;
    fif->prev=four;
    //display(head);

    //·Insert 10 after the second element, pos=3
    insertAnyPos(head,3,10);
    //display(head);

    //·Delete the element which is exactly two positions ahead of the number 8
   int cow= foundPosOfVal(head,8)+2;//cow=6
   deleteAnyPos(head,cow);
  // display(head);

   //·Insert 6 at the position that is equal to the number of elements currently divisible by 2
   int dog=divisibleByTwo(head);//dog=3
   insertAnyPos(head,dog,6);
  // display(head);

//· Delete the element that is at the position of the highest number in the list
   int meaw=highestVal(head);//meaw=47
   int fox=foundPosOfVal(head,meaw);
   deleteAnyPos(head,fox);//fow=6
   //Final List
   display(head);

   doublyToSingle(head);

   stack s;
   s.push(12);
   s.push(35);
   s.push(6);
   s.push(10);
   s.push(8);
   
   s.pop();
   s.displayStack();
   s.push(10+12);
   s.displayStack();
   
 


    return 0;
}