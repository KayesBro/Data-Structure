#include<iostream>
using namespace std;
class node
{
    public :
    int data;
    node* prev;
    node* next;

    node(int val)
    {
        data=val;
        next=prev=NULL;
    }
};

    void insertAtFirst(node* &head,int val)
    {
        node* newNode=new node(val);
        if(head==NULL)
        {
            head=newNode;
            return;
        }
        newNode->next=head;
        if(head!=NULL)
        {
            head->prev=newNode;
        }
        head=newNode;
        
    }

    void insertAtLast(node* &head,int val)
    {
        node* newNode=new node(val);
        if(head==NULL)
        {
            head=newNode;
            return;
        }
        node* temp=head;
        while(temp->next!=NULL)
        {
            temp=temp->next;
        }
        temp->next=newNode;
        newNode->prev=temp;
    }

    void insertAnyPos(node* &head,int pos,int val)
    {
        if(pos<=0)
        {
            cout<<"invalid psoition"<<endl;
            return;
        }
        if(pos==1)
        {
            insertAtFirst(head,val);
            return;
        }
        node* temp=head;
        for(int i=1;i<pos-1 && temp!=NULL;i++)
        {
            temp=temp->next;
        }
        if(temp==NULL)
        {
            cout<<"position out of bounds"<<endl;
            return;
        }
        node* newNode=new node(val);
        newNode->next=temp->next;
        newNode->prev=temp;
        if(temp->next!=NULL)
        {
            temp->next->prev=newNode;
        }
        temp->next=newNode;
    }

void deleteAtFirst(node* &head) {
    if (head == nullptr)
        return;
    node* temp = head;
    head = head->next;
    if (head != nullptr)
        head->prev = nullptr;
    delete temp;
}

void deleteAtLast(node* &head)
    {
        if(head==NULL)
        {
            return;
        }
        if(head->next==NULL)
        {
            delete head;
            head=NULL;
            return;
        }
        node* temp=head;
        while(temp->next!=NULL)
        {
            temp=temp->next;
        }
        temp->prev->next=NULL;
        delete temp;

    }

    void deleteAnyPosition(node* &head,int pos)
    {
        if(head==NULL || pos<=0)
        {
            return;
        }
        if (pos == 1)
        {
             deleteAtFirst(head);
             return;
        }
        node* temp=head;
        for(int i=1;i<pos && temp!=NULL;i++)
        {
            temp=temp->next;
        }
        if(temp==NULL)
        {
            return;
        }
        if(temp->prev!=NULL)
        {
            temp->prev->next=temp->next;

        }
        if(temp->prev!=NULL)
        {
            temp->next->prev=temp->prev;
        }
       
        delete temp;
    }

void display(node* head) 
{
     node* temp = head;
     while (temp != nullptr) 
        {
           cout << temp->data << "->";
           temp = temp->next;
        }
     cout << "null" << endl;
}
int main()
{
    
    node* head = new node(18);
    node* second = new node(15);
    node* third = new node(17);

    head->next = second;
    second->prev = head;
    second->next = third;
    third->prev = second;

    insertAtLast(head, 10);
    display(head);

    insertAtFirst(head, 16);
    display(head);

    deleteAtFirst(head);
    display(head);

    insertAnyPos(head,4,69);
    display(head);
    deleteAnyPosition(head,4);
    display(head);
    

    return 0;
}