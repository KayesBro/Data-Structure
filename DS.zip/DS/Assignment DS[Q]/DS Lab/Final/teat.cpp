#include<iostream>
using namespace std;

class node {
public:
    int data;
    node* next;
    node* prev;

    node(int value) {
        data = value;
        next = nullptr;
        prev = nullptr;
    }
};

void insertAtLast(node* &head, int value) {
    node* newNode = new node(value);
    if (head == nullptr) {
        head = newNode;
        return;
    }
    node* temp = head;
    while (temp->next != nullptr) {
        temp = temp->next;
    }
    temp->next = newNode;
    newNode->prev = temp;
}

void insertAtFirst(node* &head, int value) {
    node* newNode = new node(value);
    newNode->next = head;
    if (head != nullptr)
        head->prev = newNode;
    head = newNode;
}

void insertAtAnyPosition(node* &head, int position, int value) {
    if (position <= 0) {
        cout << "Invalid position" << endl;
        return;
    }
    if (position == 1) {
        insertAtFirst(head, value);
        return;
    }
    node* temp = head;
    for (int i = 1; i < position - 1 && temp != nullptr; i++) {
        temp = temp->next;
    }
    if (temp == nullptr) {
        cout << "Position out of bounds" << endl;
        return;
    }
    node* newNode = new node(value);
    newNode->next = temp->next;
    newNode->prev = temp;
    if (temp->next != nullptr)
        temp->next->prev = newNode;
    temp->next = newNode;
}

void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << "->";
        temp = temp->next;
    }
    cout << "null" << endl;
}

int search(node* head, int key) {
    node* temp = head;
    while (temp != nullptr) {
        if (temp->data == key)
            return 1;
        temp = temp->next;
    }
    return 0;
}

void deleteAtFirst(node* &head) {
    if (head == nullptr)
        return;
    node* temp = head;
    head = head->next;
    if (head != nullptr)
        head->prev = nullptr;
    delete temp;
}

void deleteAtLast(node* &head) {
    if (head == nullptr)
        return;
    if (head->next == nullptr) {
        delete head;
        head = nullptr;
        return;
    }
    node* temp = head;
    while (temp->next != nullptr) {
        temp = temp->next;
    }
    temp->prev->next = nullptr;
    delete temp;
}

void deleteAtAnyPosition(node* &head, int position) {
    if (head == nullptr || position <= 0)
        return;
    if (position == 1) {
        deleteAtFirst(head);
        return;
    }
    node* temp = head;
    for (int i = 1; i < position && temp != nullptr; i++) {
        temp = temp->next;
    }
    if (temp == nullptr)
        return;
    if (temp->prev != nullptr)
        temp->prev->next = temp->next;
    if (temp->next != nullptr)
        temp->next->prev = temp->prev;
    delete temp;
}

int main() {
    node* head = new node(18);
    node* second = new node(15);
    node* third = new node(17);

    head->next = second;
    second->prev = head;
    second->next = third;
    third->prev = second;

    deleteAtAnyPosition(head, 3);
    display(head);

    return 0;
}
