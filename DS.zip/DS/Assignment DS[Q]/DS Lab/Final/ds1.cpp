#include<iostream>
using namespace std;
class node{
public:
int data;
node* next;

node(int value){
    data=value;
    next=nullptr;

}

};
void insertAtLast(node* head, int value){
node* newNode=new node(value);
if(head == nullptr){
    head=newNode;
    return;
}
node* temp=head;
while(temp->next!=nullptr){
    temp=temp->next;
}
temp->next=newNode;

}

void insertAtFirst(node* &head, int value){

node* newNode=new node(value);
newNode->next=head;
head=newNode;

}
void insertAtAnyPosition(node* &head, int position, int value){

if (position<=0){
    cout<<"invalid position";
}
node* temp=head;
for(int i=1;i<position-1;i++){
    temp=temp->next;
}
node* newNode=new node(value);
newNode->next=temp->next;
temp->next=newNode;

}


void display(node* head){

node* temp=head;
while(temp!=nullptr){
    cout<<temp->data<<"->";
    temp=temp->next;

}
cout<<"null";

}

int search(node* head, int key){

node* temp=head;
while(temp!=nullptr){
        if(temp->data == key){
            return 1;
        }
    temp=temp->next;


}
return 0;

}

void deleteAtFirst(node* &head){
head=head->next;
}
void  deleteAtLast(node* head){
node* temp=head;
while(temp->next->next!=nullptr){
    temp=temp->next;
}
temp->next=nullptr;
}

void deleteAtAnyPosition(node* head, int position){
    node* temp=head;
for(int i=1; i< position-1; i++) {
  if(temp->next!=NULL) {
    temp = temp->next;
  }
}

temp->next = temp->next->next;

}
int main(){
node* head=new node(18);
node* second=new node(15);
node* third=new node(17);
head->next=second;
second->next=third;
//display(head);
insertAtLast(head, 10);
display(head);
cout<<endl;
insertAtFirst(head,16);
display(head);
cout<<endl;
insertAtAnyPosition(head, 3, 12);
display(head);
cout<<endl;
int found=search(head, 13);
if(found){
    cout<<"key found";
}
else{
    cout<<"not found";
}
cout<<endl;
deleteAtFirst(head);
display(head);
cout<<endl;
deleteAtLast(head);
display(head);
cout<<endl;
deleteAtAnyPosition(head,3);
display(head);
cout<<endl;
/*node* temp=head;
while(temp!=nullptr){
    cout<<temp->data<<"->";
    temp=temp->next;

}*/

return 0;


}
