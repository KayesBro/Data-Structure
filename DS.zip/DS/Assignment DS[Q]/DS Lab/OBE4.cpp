#include<iostream>
using namespace std;

int main()
{
    int arr[]={15,28,33,47,59,66};
    int size=sizeof(arr)/sizeof(arr[0]);

    cout<<"Delete the element from the beginning of the array."<<endl;
    for(int i=0;i<size;i++)
    {
        arr[i]=arr[i+1];
    }

    for(int i=0;i<size-1;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;

    cout<<"Insert the value 100 at position 2"<<endl;
    int nR=100,pos=2;
for(int i=size;i>pos;i--)
{
    arr[i]=arr[i-1];
}
   
arr[pos]=nR;
for(int i=0;i<size;i++)
{
    cout<<arr[i]<< " ";
}
   

    cout<< endl;

    cout<<"Insert the value 77 at the end of the array."<<endl;;

    int nE = 77;
    arr[size]= nE;


    for(int i=0;i<=size;i++)
    {
        cout<<arr[i]<<" ";
    }



    


    return 0;
}