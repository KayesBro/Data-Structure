#include<iostream>
using namespace std;

int main()
{
    int arr[10]={10,11,12,13,14,15,16,17,18,19};
    int count1=0,count2=0;
   // int size=sizeof(arr)/sizeof(arr[0]);
    int evenArr[10];
    


    for(int i=0;i<10;i++)
    {
        if(arr[i]%2==0)
        {
            count1++;

            
        }
    }

 
    for(int i=0;i<10;i++)
    {
        if(arr[i]%2==0)
        {
            evenArr[i]=arr[i]; 
            
        }
    }

    for(int i=0;i<10;i++)
    {
        cout<<evenArr[i]<<" ";
    }

    
    cout<<endl;
    cout<<"Even numbers : "<<count1<<endl;

    return 0;
}