#include<iostream>
using namespace std;

int main()
{
    int arr[10]={10,11,12,13,14,15,16,17,18,19};
    int count1=0,count2=0;
    


    for(int i=0;i<10;i++)
    {
        if(arr[i]%2==0)
        {
            count1++;

            
        }
    }
    for(int i=0;i<10;i++)
    {
        if(arr[i]%2==0)
        {
            cout<<arr[i]<<" "; 
            
        }
    }
    cout<<endl;
    cout<<"Even numbers : "<<count1<<endl;
    
for(int i=0;i<10;i++)
    {
        if(arr[i]%2!=0)
        {
            count2++;

            
        }
    }
    for(int i=0;i<10;i++)
    {
        if(arr[i]%2!=0)
        {
            cout<<arr[i]<<" "; 
            
        }
    }
    cout<<endl;
    cout<<"odd numbers : "<<count2<<endl;

    return 0;
}