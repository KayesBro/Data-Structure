#include<iostream>
using namespace std;

int main()
{
    int A[10],count=0,n;
    cout<<"Enter 10 Array Elements : ";
    for(int i=0; i<10;i++)
    {
        cin>>A[i];
    }
    cout<<endl;

    cout<<"Input a number to search: ";
    cin>>n;

    for(int i=0;i<10;i++)
    {
        if(A[i]==n)
        {
            count++;
            
        }
    }

    cout<<" The number "<<n<<" " <<count<<" times in the array "<<endl;




    return 0;
}