#include<iostream>
using namespace std;

int main()
{
    int A[6]={1,4,6,3,6,9};
    int B[6]={5, 3, 7, 1, 2, 6};
    int C[13];
    int count=0;

    for(int i=0;i<6;i++)
    {
        for(int j=0;j<6;j++)
        {
            if(A[i]==B[j])
            {
                cout<<A[i]<<" ";
                count++;
                break;
            }
        
        }
          
    }
   
   cout<<endl;
   
    if(count==0)
    {
        cout<<"No common element!"<<endl;
    }
    
    cout<<"Total common elements:"<<count<<endl;




    return 0;
}