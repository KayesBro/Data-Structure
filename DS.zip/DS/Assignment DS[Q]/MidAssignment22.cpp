#include<iostream>
#include<string>
using namespace std;
int main()
{

    int TRcount=0,MEDcount=0,BScount=0,GOcount=0,c;
    int cp;
    string cpyT,cpyM,cpyB,cpyG;
    int maxApplicant = 25;
    int maxTotalApplicant = 100;
    cout <<"1.Request Token" << endl;
    cout << "2.Call Next Customer at Counter" << endl;
    cout <<"3.Generate Daily Summary \n" << endl;
    cout<<"'Travel Visa' for TR\n'Medical Visa' for MED\n'Business Visa' for BS\n'Government Officials Visa' for GO\n"<<endl;
    string vt;
    string tr="TR" ;
    string med="MED";
    string bs="BS" ;
    string go="GO";
    string gds="GDS";
    string cn="CN";
    for(int i=1; i<=maxTotalApplicant; i++)
    {
        cout << "\n----- Embassy Consulate Service System -----" << endl;
        cout << "Enter Visa Type (TR/MED/BS/GO): \nCall Next Customer at Counter (CN) :\nGenerate Daily Summary (GDS) :\n"<<endl;
        cout<<"Enter What You Want : ";
        cin>>vt;
        if(vt== tr || vt== med || vt== bs || vt== go)
        {
            cout<<"Your token is: "<<vt<<"-"<<i<<endl;

        }

                if(vt==tr)
        {
            TRcount++;
            cpyT =vt;
             cp=i;
        }
        else if(vt==med)
        {
            MEDcount++;
            cpyM =vt;
             cp=i;
        }
        else if(vt==bs)
        {
            BScount++;
            cpyB =vt;
             cp=i;
        }
        else if(vt==go)
        {
            GOcount++;
            cpyG =vt;
             cp=i;
        }

          if(vt==gds)
        {
                cout<<"\n------Applicants served by Visa Type : ------"<<endl;
                cout<<"TR (Travel): "<< TRcount<<endl;
                cout<<"MED (Medical): "<<MEDcount<<endl;
                cout<<"BS (Business): "<<BScount<<endl;
                cout<<"GO (Government Officials): "<<GOcount<<endl<<endl;

               cout<<"Total Applicants Served : "<<(TRcount+MEDcount+BScount+GOcount)<<endl;
        }

        if(vt==cn)
        {
            cout<<"\n------Call Next Customer at Counter : ------"<<endl;
            cout<<"'Travel Visa' for 1\n'Medical Visa' for 2\n'Business Visa' for 3\n'Government Officials Visa' for 4\n"<<endl;
            cout<<"Enter Counter Number (1-4): ";
            cin>>c;
            if(c==1)
            {
                cout<<"Counter 1, Please serve the token number :"<<cpyT<<"-"<<cp<<endl;
            }
          else  if(c==2)
            {
                cout<<"Counter 2, Please serve the token number :"<<cpyM<<"-"<<cp<<endl;
            }
            else if(c==3)
            {
                cout<<"Counter 3, Please serve the token number :"<<cpyB<<"-"<<cp<<endl;
            }
          else  if(c==4)
            {
                cout<<"Counter 4, Please serve the token number :"<<cpyG<<"-"<<cp<<endl;
            }
        }
       else if(vt != tr && vt != med && vt != bs && vt != go && vt != cn && vt != gds)
        {
            cout<<"Invalid Typing. Please Try Again in Capital Letter"<<endl;
            break;
        }
    }
    return 0;
}
