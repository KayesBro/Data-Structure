rear->next=newNode;
        rear=newNode;
        newNode->next=front;