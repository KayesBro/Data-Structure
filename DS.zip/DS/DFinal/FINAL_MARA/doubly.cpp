#include<iostream>
using namespace std;
class node
{
    public : 
    int data;
    node* next;
    node* prev;
    node(int val)
    {
        data=val;
        next=NULL;
        prev=NULL;
    }
};
void insertAtLast(node* head,int val)
{
    
}

int main()
{
    

    return 0;
}