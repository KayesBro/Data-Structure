#include<iostream>
using namespace std;
class node
{
    public : 
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }
};
class queue
{
    public :
    node* front;
    node* rear;
    public :
    queue()
    {
        front=rear=NULL;
    }

    bool isEmpty()
    {
        if(front==NULL)
        {
            return true;
        }
        return false;
    }
    void enQueue(int val)
    {
        node* newNode=new node(val);
        if(isEmpty()==true)
        {
            front=rear=newNode;
            rear->next=front;  
        }
        else
        {
            newNode->next=front;
            rear->next=newNode;
            rear=newNode;
        }
        
    }
    void deQueue()
    {
        if(isEmpty()==true)
        {
            cout<<"Queue is Underflow"<<endl;
            return;
        }
        front=front->next;
    }
    void display()
    {
        node* temp=front;
        while(temp!=NULL)
        {
            cout<<temp->data<<"->";
            temp=temp->next;
        }
        cout<<endl;
    }
};
int main()
{
    queue q;
    q.enQueue(1);
   // q.enQueue(2);
   // q.enQueue(3);
    q.display();
   // q.deQueue();
   // q.display();
    

    return 0;
}