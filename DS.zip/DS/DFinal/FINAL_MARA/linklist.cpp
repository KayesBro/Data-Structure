#include<iostream>
using namespace std;
class node
{
    public : 
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }
};
void insertAtLast(node* head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newNode;
}
void insertAtHead(node* &head,int val)
{ 
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
   newNode->next=head;
   head=newNode;
}
void deleteAtHead(node* &head)
{
    
    head=head->next;
}
void deleteAtLast(node* &head)
{
    if(head==NULL)
    {
        cout<<"List list Underflow"<<endl;
        return;
    }
    node* temp=head;
    while(temp->next->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=NULL;
}
void display(node* head)
{
    node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<"->";
        temp=temp->next;
    }
    cout<<endl;
}
int main()
{
    node* head=new node(18);
    node* second=new node(15);
    node* third=new node(17);
    head->next=second;
    second->next=third;
    display(head);
    insertAtHead(head,11);
    display(head);
    insertAtLast(head,21);
    display(head);
    deleteAtHead(head);
    display(head);
    deleteAtLast(head);
    display(head);

    return 0;
}