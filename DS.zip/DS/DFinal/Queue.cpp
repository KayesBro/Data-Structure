#include<iostream>
using namespace std;
class node
{
    public : 
    int data;
    node* next;
    node(int val)
    {
        data=val;
        next=NULL;
    }

};
class queue
{
    public : 
    node* front;
    node* rear;
    queue()
    {
        front=rear=NULL;
    }
    bool isEmpty()
    {
        if(front==NULL)
        {
            return true;
        }
        return false;
    }
    void enqueue(int val)
    {
        node* newNode=new node(val);
        if(isEmpty()==true)
        {
            front=rear=newNode;
            return;
        }
        rear->next=newNode;
        rear=newNode;
    }
    void dequeue()
    {
        if(isEmpty()==true)
        {
            cout<<"Queue underFlow"<<endl;
            return;
        }
        front=front->next;
    }
    void display()
    {
        node* current=front;
        while(current!=nullptr)
        {
            cout<<current->data<<"->";
            current=current->next;
        }
    
    }
    

};
int main()
{
    queue q;
q.enqueue(5);
q.enqueue(6);
q.enqueue(7);
q.display();
cout<<endl;
q.dequeue();
q.display();
    

    return 0;
}