#include<iostream>
using namespace std;
class node
{
    public : 
    int data;
    node* next;

    node(int val)
    {
        data=val;
        next=NULL;
    }
};
void insertAtLast(node* head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
        return;
    }
    node* temp=head;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }

    temp->next=newNode;

}
void insertAtHead(node* &head,int val)
{
    node* newNode=new node(val);
    if(head==NULL)
    {
        head=newNode;
    }
    newNode->next=head;
    head=newNode;
}

int search(node* head,int key)
{
    node* temp=head;
    while(temp!=NULL)
    {
        if(temp->data==key)
        {
            return 1;
        }
        temp=temp->next;
    }
    return 0;
}
void deleteAtHead(node* &head)
{
    head=head->next;
}
void deleteAtLast(node* head)
{
    node* temp=head;
    while(temp->next->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=NULL;
}
void display(node* head)
{
    node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<"-> ";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}

int main()
{
    node* head=new node(3);
    node* sec=new node(5);
    node* thir=new node(7);

    head->next=sec;
    sec->next=thir;
    insertAtLast(head,9);
    display(head);
    insertAtHead(head,1);
    display(head);
    deleteAtHead(head);
    display(head);
    deleteAtLast(head);
    display(head);

   int found= search(head,8);
   if(found)
   cout<<"Founded"<<endl;
   else
   cout<<"Not Founded"<<endl;
    

    return 0;
}